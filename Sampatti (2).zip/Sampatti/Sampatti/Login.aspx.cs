﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Sampatti
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string uid = TextBox1.Text;
            string pwd = TextBox2.Text;

            if (uid == "" || pwd == "")
            {
                message.Text = "Userid & Password both are mandatory !";
                // Response.Redirect("login");
            }
            else if ((uid.Equals("89385821") || uid.Equals("89385820") || uid.Equals("89385870") || uid.Equals("996458")) && pwd.Equals("pass@123"))
            {

                Session["userid"] = uid;
                Response.Redirect("Home1.aspx");

            }
            else
            {
                message.Text = "Invalid Credentials !";
                //Response.Redirect("Login.aspx");
            }
        }
    }
}