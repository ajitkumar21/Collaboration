﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Sampatti
{
    public partial class Transfer : System.Web.UI.Page
    {
        string conn = ConfigurationManager.ConnectionStrings["temp"].ToString();
        public static Dictionary<string, string> sp = new Dictionary<string, string>();


        protected void Page_Load(object sender, EventArgs e)
        {

            int i = 0;
            sp.Clear();
            string a = Session["userid"].ToString();
            string sql = "";

            using (System.Data.SqlClient.SqlConnection con = new System.Data.SqlClient.SqlConnection(conn))
            {
                sql = "select * from Asset";

                using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand(sql, con))
                {
                    con.Open();

                    System.Data.SqlClient.SqlDataReader sdr = cmd.ExecuteReader();
                    if (sdr.HasRows)
                    {
                        while (sdr.Read())
                        {
                   
                            sp.Add("id" + i + "", sdr["id"].ToString());
                            sp.Add("mcatg" + i + "", sdr["Major_Category"].ToString());
                       
                            sp.Add("subcat1" + i + "", sdr["Sub_Cat"].ToString());
                            sp.Add("subcat2" + i + "", sdr["SuB_Category"].ToString());
                            sp.Add("descp" + i + "", sdr["Asset_Description"].ToString());
                            sp.Add("location" + i + "", sdr["Location"].ToString());

                            i++;
                        }
                    }
                }
            }
          
        }

        protected void Button1_Click(object sender, EventArgs e)
        {

            string a = Request.Form["abcd"];
            if (a.Equals("102"))
            {
                Response.Redirect("Home1.aspx");

            }
        }
    }
}